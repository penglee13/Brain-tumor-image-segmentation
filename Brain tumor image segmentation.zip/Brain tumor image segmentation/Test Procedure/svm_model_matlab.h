void model_to_matlab_structure(mxArray *plhs[], int num_of_feature, struct svm_model *model);
